/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodosnumericos;

import org.nfunk.jep.JEP;

/**
 *
 * @author Pc
 */
public class Bisección {
    private String expresion = "";
    
    public Bisección(String expresion){
        this.expresion = expresion;
        
    }
    
    public double evaluar(double x){
        JEP j = new JEP();
        j.addStandardFunctions();
        j.addStandardConstants();
        j.addVariable("x", x);
        j.parseExpression(expresion);
        
        if (!j.hasError()){
        return j.getValue();
    } else {
            return Double.NaN;
            
            }
    }
}
