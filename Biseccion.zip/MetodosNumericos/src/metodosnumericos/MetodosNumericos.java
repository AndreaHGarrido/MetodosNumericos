/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodosnumericos;

/**
 *
 * @author Pc
 */
public class MetodosNumericos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Metodo metodo = new Metodo();
        
        metodo.setBisección("2x^3 + 11x^2 + 7x – 3");
        double raiz = metodo.biseccion (-5, 5, 0.001);
        System.out.println("La raiz es: " + raiz);
        
        metodo.setBisección("-x^4 – 3x^3 – 7x^2 + 12x + 2");
        double raiz2 = metodo.biseccion(-1, 1, 0.001);
        System.out.println("La raiz es: "+ raiz2);
        
        metodo.setBisección("x^3 – 6x^2 + 11x – 6");
        double raiz3 = metodo.biseccion (-2, 2, 0.001);
        System.out.println("La raiz es: " + raiz);
        
        metodo.setBisección("3x^4 + 5x^3 + 8x^2 – 2x -6");
        double raiz4 = metodo.biseccion (0, 2, 0.001);
        System.out.println("La raiz es: " + raiz);
    }
    
    
}
